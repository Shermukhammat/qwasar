# Welcome to My Mr Clean
***

## Task
What is the problem? And where is the challenge?

I had problem  working wth Wikipedia API and Visualiton part !

## Description
How have you solved the problem?

Of course, by searched on google and stackoverflow !

## Installation
How to install your project? npm install? make? make re?

I used requests, regex, pandasa, matplotlib and seaborn librares! So I wrote mylib modile! 
It includes data cleaning functions!

## Usage
How does it work?
This program consis of 7 parts:
1.get_content function gets conten from wikipedia wth wiki API;
2.merge_content function cleaning data;
3.tokinize function split data into list;
4.lower_colection function convert to lower case;
5.count_frequency function counts frequency words;
6.print_most_frequent function make a table most n frequency words;
7.remove_stop_words functio remove unnessesary words.


```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
